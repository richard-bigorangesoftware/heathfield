<?php

function hc_load_calendar_via_ajax() {
	if(isset($_POST['hc_nonce']) && wp_verify_nonce($_POST['hc_nonce'], 'hc_calendar_nonce')) {

		$current_month 	= isset( $_POST['hc_current_month'] ) ? absint( $_POST['hc_current_month'] ) : 0;
		$year 			= absint( $_POST['hc_year'] );

		if( $current_month == 12 && $_POST['action_2'] == 'next_month' )
			$year++;
		elseif( $current_month == 1 && $_POST['action_2'] == 'prev_month' )
			$year--;

		die( hc_get_events_calendar( $year ) );
	}
}
add_action('wp_ajax_hc_load_calendar', 'hc_load_calendar_via_ajax');
add_action('wp_ajax_nopriv_hc_load_calendar', 'hc_load_calendar_via_ajax');

