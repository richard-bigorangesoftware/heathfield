<?php

/**
 * Install
 *
 * Runs on plugin install.
 *
 * @access      private
 * @since       1.0 
 * @return      void
*/

function hc_install() {
	
	// setup the download custom post type
	hc_setup_post_types();
	
	// clear permalinks
	flush_rewrite_rules();
}
register_activation_hook( HC_PLUGIN_FILE, 'hc_install' );