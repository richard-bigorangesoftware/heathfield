<?php

function hc_get_events_list($display = 'all', $category = null, $intMonth=null, $intYear=null, $insCalendar = 'School' ) {
    hc_enqueue_styles();
    
	if( !$intMonth ){
            $intMonth = date('m');
        } else {
        }
	if( !$intYear ){
            $intYear = date('Y');
        }
        
        $arrFilter = array(
                array(
                        'key' => 'hc_event_month',
                        'value' => sprintf( '%1$02d', $intMonth ),
                        'compare' => '='
                    ),
                array(
                        'key' => 'hc_event_year',
                        'value' => $intYear,
                        'compare' => '='
                )
            );
        
        if(!is_user_logged_in()){
            $arrFilter[] = array(
                    'key' => 'hc_private',
                    'value' => 0,
                    'compare' => '='
                );
        }
        $events = new WP_Query(array(
            'post_type' => 'hc_event',
            'posts_per_page' => -1,
            'orderby' => 'meta_value',
            'meta_key' => 'hc_event_date_time',
            'calendar' => $insCalendar,
            'meta_query' => $arrFilter
        ));
        $intNextYear = $intPrevYear = $intYear;
        $intNextMonth = $intMonth+1;
        $intPrevMonth = $intMonth-1;
        if( $intMonth==1 ){
            $intPrevYear--;
            $intPrevMonth = 12;
        } elseif ( $intMonth==12 ) {
            $intNextYear++;
            $intNextMonth = 1;
        }
        
        $strNextURL = add_query_arg( array( 'intMonth'=>$intNextMonth, 'intYear'=>$intNextYear ), get_permalink());
        $strPrevURL = add_query_arg( array( 'intMonth'=>$intPrevMonth, 'intYear'=>$intPrevYear ), get_permalink());
        $strHTML = "
                <div id='hc-list-wrapper'>
                    <div class='hc-list-nav-wrapper'>
                        <a href='$strPrevURL' class='hc-prev-month'>Previous Month</a>
                        <a href='$strNextURL' class='hc-next-month'>Next Month</a>
                    </div>
                    <h2 class='hc-month-header'>". date( 'F', mktime( null, null, null, $intMonth, 1, $intYear )). "</h2>
                    ". transformCalendarPostsToHTML( $events, true, true ) ."
                </div>
                ";
        echo $strHTML;
}