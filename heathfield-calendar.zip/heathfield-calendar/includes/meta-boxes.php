<?php

/**
 * Metabox Functions
 *
 * @access      private
 * @since       1.0 
 * @return      void
*/


/**
 * Add Event Meta Box
 *
 * @access      private
 * @since       1.0 
 * @return      void
*/

function hc_add_event_meta_box() {
	add_meta_box('hc_event_config', __('Event Details', 'bos_hc'), 'hc_render_event_config_meta_box', 'hc_event', 'normal', 'default');
}
add_action('add_meta_boxes', 'hc_add_event_meta_box');


/**
 * Renders the Event Configuration Meta Box
 *
 * @access      private
 * @since       1.0 
 * @return      void
*/

function hc_render_event_config_meta_box() {
	global $post;
	
	$meta = get_post_custom($post->ID);
	$arrChecked = array( "", "checked='checked'" );
	echo '<input type="hidden" name="hc_meta_box_nonce" value="' . wp_create_nonce(basename(__FILE__)) . '" />';
	
	echo '<table class="form-table">';
		
		do_action('hc_event_meta_box_before');
		
		echo '<tr class="hc_meta_box_row">';
	
			echo '<td class="hc_meta_box_td" colspan="2"><label for="hc_event_date">' . __('Event Date', 'bos_hc') . '</label></td>';
			
			echo '<td class="hc_meta_box_td" colspan="4">';
				$date = isset( $meta['hc_event_date'][0] ) ? date( 'm/d/Y', $meta['hc_event_date'][0] ) : '';
				echo '<input type="text" class="hc_datepicker" name="hc_event_date" value="' . esc_attr( $date ) . '" placeholder="mm/dd/yyyy"/>';
			echo '</td>';
			
		echo '</tr>';
		
		echo '<tr class="hc_meta_box_row">';
	
			echo '<td class="hc_meta_box_td" colspan="2"><label for="hc_event_time">' . __('Event Time', 'bos_hc') . '</label></td>';

			$time 		= isset( $meta['hc_event_time'][0] ) 			? date('m/d/Y', $meta['hc_event_time'][0]) : '';
			$hour 		= isset( $meta['hc_event_time_hour'][0] ) 		? $meta['hc_event_time_hour'][0] : '00';
			if( $hour > 24 ) $hour = $hour - 24;
			$minute 	= isset( $meta['hc_event_time_minute'][0] ) 	? $meta['hc_event_time_minute'][0] : '00';
			
			echo '
                                <td class="hc_meta_box_td" colspan="4">
                                    <input type="text" class="small-text" name="hc_event_time_hour" value="' . sprintf( '%1$02d', absint( $hour )) . '"/>
                                    <span class="hc_event_time_separator">&nbsp;:&nbsp;</span>
                                    <input type="text" class="small-text" name="hc_event_time_minute" value="' . sprintf( '%1$02d', absint( $minute )) . '"/>
                                </td>
                           </tr>
                            <tr class="hc_meta_box_row">
                                <td colspan="2">
                                    Requires log in?: 
                                </td>
                                <td colspan="4">
                                    <input type="checkbox" '. $arrChecked[$meta['hc_private'][0]] .' class="small-text" name="hc_private" value="1"/>
                                </td>
                            </tr>
                    ';
		
		do_action('hc_event_meta_box_after');
	
	echo '</table>';

}


/**
 * Download Meta Box Save
 *
 * Save data from meta box.
 *
 * @access      private
 * @since       1.0 
 * @return      void
*/

function hc_meta_box_save($post_id) {
	global $post;
	
	// verify nonce
	if (!isset($_POST['hc_meta_box_nonce']) || !wp_verify_nonce($_POST['hc_meta_box_nonce'], basename(__FILE__))) {
		return $post_id;
	}

	// check autosave
	if ( (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || ( defined('DOING_AJAX') && DOING_AJAX) || isset($_REQUEST['bulk_edit']) ) return $post_id;
	
	//don't save if only a revision
	if ( isset($post->post_type) && $post->post_type == 'revision' ) return $post_id;

	// check permissions
	if (isset($_POST['post_type']) && 'page' == $_POST['post_type']) {
		if (!current_user_can('edit_page', $post_id)) {
			return $post_id;
		}
	} elseif (!current_user_can('edit_post', $post_id)) {
		return $post_id;
	}
	
	// retrieve and store event date / time
	
	if(!isset($_POST['hc_event_date']))
		return $post_id;
		
	$date 			= sanitize_text_field( $_POST['hc_event_date'] );
	$hours 			= sanitize_text_field( absint( $_POST['hc_event_time_hour'] ) );
	$minutes		= sanitize_text_field( absint( $_POST['hc_event_time_minute'] ) );
	$recurring		= isset($_POST['hc_event_recurring']) ? $_POST['hc_event_recurring'] : '';
	$private		= isset($_POST['hc_private']) ? 1 : 0;
	
	$day 	= date( 'd', strtotime( $date ) );
	$month 	= date( 'm', strtotime( $date ) );
	$year 	= date( 'Y', strtotime( $date ) );

	$final_date_time = mktime( $hours, $minutes, 0, $month, $day, $year );
	
	update_post_meta($post_id, 'hc_event_date_time', $final_date_time);
	update_post_meta($post_id, 'hc_event_date', strtotime($date));
	update_post_meta($post_id, 'hc_event_day', date('D', strtotime($date)));
	update_post_meta($post_id, 'hc_event_day_of_month', $day);
	update_post_meta($post_id, 'hc_event_month', $month);
	update_post_meta($post_id, 'hc_event_year', $year);
	update_post_meta($post_id, 'hc_event_time_hour', $hours);
	update_post_meta($post_id, 'hc_event_time_minute', $minutes);
	update_post_meta($post_id, 'hc_event_recurring', $recurring);
	update_post_meta($post_id, 'hc_private', $private);
}
add_action('save_post', 'hc_meta_box_save');