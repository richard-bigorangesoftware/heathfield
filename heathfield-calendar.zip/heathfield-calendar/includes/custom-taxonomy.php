<?php

/**
 * Addition of custom taxonomy for multiple Calendars
 *
 *
 * @author 		Nathan Payne - nathan@nathanpayne.co.uk
*/

function add_custom_taxonomies() {
	register_taxonomy('Calendar', 'post', array(
		'hierarchical' => true,
		'labels' => array(
			'name' => _x( 'Calendar', 'taxonomy general name' ),
			'singular_name' => _x( 'Calendar', 'taxonomy singular name' ),
			'search_items' =>  __( 'Search Calendar' ),
			'all_items' => __( 'All Calendar' ),
			'parent_item' => __( 'Parent Calendar' ),
			'parent_item_colon' => __( 'Parent Calendar:' ),
			'edit_item' => __( 'Edit Calendar' ),
			'update_item' => __( 'Update Calendar' ),
			'add_new_item' => __( 'Add New Calendar' ),
			'new_item_name' => __( 'New Calendar Name' ),
			'menu_name' => __( 'Calendar' ),
		),
		'rewrite' => array(
			'slug' => 'calendar',
			'with_front' => false,
			'hierarchical' => false
		),
		'hierarchical' => true //this in theory should be false, but it gives you the tag UI on the admin page which doesn't make as much sense... So true it is.
	));
}
add_action( 'init', 'add_custom_taxonomies', 0 );

 ?>