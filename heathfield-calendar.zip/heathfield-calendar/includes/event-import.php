<?php 

/**
 * Import events via CSV upload
 * @author Nathan Payne - nathan@nathanpayne.co.uk
*/

/**
 * Addition of admin menu item
*/

add_action( 'admin_menu', 'register_my_custom_menu_page' );

function register_my_custom_menu_page(){
	add_menu_page( 'Event Import', 'Event Import', 'manage_options', 'heathfield-calendar/event-import.php', 'eventImport' );
}

/**
 * Event Import page UI and "controller" against potential form post
*/

function eventImport(){

	if( !empty( $_POST ) ){
		process_upload();
	} else { 
		?>
		<div class="wrap">
			<h2>Event Import</h2>
			<p>This page allow you to import events from a CSV file.</p>
			<form method="post" enctype="multipart/form-data" action="admin.php?page=heathfield-calendar/event-import.php">
				</p><label for="uploadevents">Upload CSV: </label>
				<input id="uploadevents" type="file" name="events"></p>
				<p><input type="submit" name="submit" id="submit" class="button button-primary" value="Import"></p>
			</form>
		</div>
		<?php
	}

}

/**
 * CSV Processor
*/

function process_upload(){
	$csv = $_FILES['events'];
	$count = 0;

	if ($csv['error'][$key] == 0) {
		$filetmp = $csv['tmp_name'];
		if (($handle = fopen($filetmp, "r")) !== FALSE) {
			$SkipTitles = true;
			//make sure we don't try to process to many events and kill the server! 1,000 should be more than enough?!
			while (($aData = fgetcsv($handle, 1000, ",")) !== FALSE) {
				if( $SkipTitles ){
					//Skip the first line in the CSV as it is only title data
					$SkipTitles = false;
					continue;
				}
				import_event($aData);
				$count++;
			}
			?>

			<div class="wrap">
				<h2>Event Import</h2>
				<p>You have imported <?php echo $count ?> events.</p>
			</div>

			<?php
			fclose($handle);
		}
		unlink($filetmp); // delete the temp csv file
	}

}

/**
 * Event importer with calendar selection
*/

function import_event( $inaData ){

	//event skeleton
	$aCustomPost =  array(
		'post_title' => $inaData[0],
		'post_status' => 'publish',
		'post_type' => 'hc_event'
	);

	$post_id = wp_insert_post( $aCustomPost );

	//WARNING: We can't use strtotime here as it was converting the month and day of month the wrong wat round.
	//strtotime will only guess the format you provide and won't always get it right for dates like 07/10/2014
	//DateTime CreateFromFormat gets around thise issues by telling it theformat we expect.
	$time = DateTime::createFromFormat( 'd/m/Y H:i', $inaData[2] );

	$day 	= date( 'd', $time->getTimestamp() );
	$month 	= date( 'm', $time->getTimestamp() );
	$year 	= date( 'Y', $time->getTimestamp() );

	//usual custom fields for the hc_event type
	update_post_meta($post_id, 'hc_event_date_time', $time->getTimestamp() );
	update_post_meta($post_id, 'hc_event_date', $time->getTimestamp() );
	update_post_meta($post_id, 'hc_event_day', date('D', $time->getTimestamp()));
	update_post_meta($post_id, 'hc_event_day_of_month', $day);
	update_post_meta($post_id, 'hc_event_month', $month);
	update_post_meta($post_id, 'hc_event_year', $year);
	update_post_meta($post_id, 'hc_event_time_hour',  date( 'H', $time->getTimestamp()));
	update_post_meta($post_id, 'hc_event_time_minute',  date( 'i', $time->getTimestamp()));
	update_post_meta($post_id, 'hc_event_recurring', '');
	update_post_meta($post_id, 'hc_private', 0);

	$aMatches = explode(';', $inaData[5] );

	//This decides which calendar we add the event to
	if( in_array('#Matches', $aMatches) )
		$term = get_term_by( 'name', 'Sports', 'Calendar' );
	else
		$term = get_term_by( 'name', 'School', 'Calendar' );

	//Add to the calendar
	wp_set_post_terms( $post_id, (int) $term->term_id, 'Calendar' );

}

?>