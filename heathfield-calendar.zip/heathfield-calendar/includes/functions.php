<?php

/**
 * Month Num To Name
 *
 * Takes a month number and returns the
 * three letter name of it.
 *
 * @access      public
 * @since       1.0
 * @return      string
*/

function hc_month_num_to_name($n) {
    $timestamp = mktime( 0, 0, 0, $n, 1, 2005 );
    return date_i18n( 'M', $timestamp);
}

/**
 * Determines whether the current page has a calendar on it
 *
 * @access      public
 * @since       1.0
 * @return      string
*/

function hc_is_calendar_page() {
	global $post;

	if( !is_object( $post ) )
		return false;

	if ( strpos($post->post_content, '[hc_events_calendar') !== false )
		return true;
	return false;
}


/**
 * Retrieves the calendar date for an event
 *
 * @access      public
 * @since       1.0
 * @param		$event_id int The ID number of the event
 * @param		$formatted bool Whether to return a time stamp or the nicely formatted date
 * @return      string
*/
function hc_get_event_date( $event_id, $formatted = true ) {
	$date = get_post_meta( $event_id, 'hc_event_date_time', true );
	if( $formatted )
		$date = date_i18n( get_option('date_format' ), $date );

	return $date;
}


/**
 * Retrieves the time for an event
 *
 * @access      public
 * @since       1.0
 * @param		$event_id int The ID number of the event
 * @return      array
*/
function hc_get_event_time( $event_id ) {
	$start_time = hc_get_event_start_time( $event_id );
	$end_time = hc_get_event_end_time( $event_id );

	return apply_filters( 'hc_event_time', array( 'start' => $start_time, 'end' => $end_time ) );
}


/**
 * Retrieves the start time for an event
 *
 * @access      public
 * @since       1.0
 * @param		$event_id int The ID number of the event
 * @return      string
*/

function hc_get_event_start_time($event_id) {
	$start 	= get_post_meta($event_id, 'hc_event_date', true);

	$day 	= date( 'd', $start );
	$month 	= date( 'm', $start );
	$year 	= date( 'Y', $start );

	$hour 	= absint( get_post_meta( $event_id, 'hc_event_time_hour', true ) );
	$minute = absint( get_post_meta( $event_id, 'hc_event_time_minute', true ) );
	$am_pm 	= get_post_meta( $event_id, 'hc_event_time_am_pm', true );

	$hour 	= $hour ? $hour : null;
	$minute = $minute ? $minute : null;
	$am_pm 	= $am_pm ? $am_pm : null;

	if( $am_pm == 'pm' && $hour < 12 )
		$hour += 12;
	elseif( $am_pm == 'am' && $hour >= 12 )
		$hour -= 12;

	$time = date_i18n( get_option( 'time_format' ), mktime( $hour, $minute, 0, $month, $day, $year ) );

	return apply_filters( 'hc_event_start_time', $time, $hour, $minute, $am_pm );
}


/**
 * Retrieves the end time for an event
 *
 * @access      public
 * @since       1.0
 * @param		$event_id int The ID number of the event
 * @return      string
*/

function hc_get_event_end_time( $event_id ) {
	$start 	= get_post_meta( $event_id, 'hc_event_date', true );

	$day 	= date( 'd', $start );
	$month 	= date( 'm', $start );
	$year 	= date( 'Y', $start );

	$hour 	= get_post_meta( $event_id, 'hc_event_end_time_hour', true );
	$minute = get_post_meta( $event_id, 'hc_event_end_time_minute', true );
	$am_pm 	= get_post_meta( $event_id, 'hc_event_end_time_am_pm', true );

	$hour 	= $hour 	? $hour 	: null;
	$minute = $minute 	? $minute 	: null;
	$am_pm 	= $am_pm 	? $am_pm 	: null;

	if( $am_pm == 'pm' && $hour < 12 )
		$hour += 12;
	elseif( $am_pm == 'am' && $hour >= 12 )
		$hour -= 12;

	$time = date_i18n( get_option( 'time_format' ), mktime( $hour, $minute, 0, $month, $day, $year ) );

	return apply_filters( 'hc_event_end_time', $time, $hour, $minute );
}

function transformCalendarPostsToHTML( WP_Query $objEvents, $blnIncludeDate = false, $blnShowNoRecords = false ){
    if( sizeof( $objEvents->posts )) {
        if ( !$blnIncludeDate ){
            $strHTML.= '<ul class="hc_events_list">';
        }
        foreach( $objEvents->posts as $objEvent ) {
            if( 
                $blnIncludeDate && (
                    $intDay != $objEvent->hc_event_day_of_month ||
                    $intMonth != $objEvent->hc_event_month ||
                    $intYear != $objEvent->hc_event_year
                )
            ){
                if ( $strHTML ){
                    $strHTML.= '</ul>';
                }
                $strHTML.= '
                        <h3 class="hc-day-header">'. date( 'l jS', $objEvent->hc_event_date_time ) .'</h3>
                        <ul class="hc_events_list">
                    ';
            }
            $intDay = $objEvent->hc_event_day_of_month;
            $intMonth = $objEvent->hc_event_month;
            $intYear = $objEvent->hc_event_year;
                $strHTML.= "
                        <li>
                            <span class='hc_event_date'>". sprintf( '%1$02d', $objEvent->hc_event_time_hour ) .".". sprintf( '%1$02d', $objEvent->hc_event_time_minute ) ."</span>
                            <span class='hc_event_title'>" . get_the_title($objEvent->ID) . "</span>
                        </li>
                    ";
        }
        $strHTML.= '</ul>';
    } elseif( $blnShowNoRecords ){
        $strHTML.= "<h3>No events found</h3>";
    }
    return $strHTML;
}