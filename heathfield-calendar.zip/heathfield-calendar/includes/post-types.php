<?php

/**
 * Setup Events Post Type
 *
 * Registers the Events CPT.
 *
 * @access      private
 * @since       1.0 
 * @return      void
*/

function hc_setup_post_types() {
	
	$event_labels =  apply_filters('hc_event_labels', array(
		'name' 				=> __( 'Events', 'bos_hc' ),
		'singular_name' 	=> __( 'Event', 'bos_hc' ),
		'add_new' 			=> __( 'Add New', 'bos_hc' ),
		'add_new_item' 		=> __( 'Add New Event', 'bos_hc' ),
		'edit_item' 		=> __( 'Edit Event', 'bos_hc' ),
		'new_item' 			=> __( 'New Event', 'bos_hc' ),
		'all_items' 		=> __( 'All Events', 'bos_hc' ),
		'view_item' 		=> __( 'View Event', 'bos_hc' ),
		'search_items' 		=> __( 'Search Events', 'bos_hc' ),
		'not_found' 		=> __( 'No Events found', 'bos_hc' ),
		'not_found_in_trash'=> __( 'No Events found in Trash', 'bos_hc') , 
		'parent_item_colon' => '',
		'menu_name' 		=> __( 'Events', 'bos_hc')
	) );
	
	$event_args = array(
		'labels' 				=> $event_labels,
		'public' 				=> true,
		'publicly_queryable' 	=> true,
		'show_ui' 				=> true, 
		'show_in_menu' 			=> true, 
		'query_var' 			=> true,
		'rewrite' 				=> apply_filters( 'hc_event_rewrite', array( 'slug' => 'events', 'with_front' => false ) ),
		'capability_type' 		=> apply_filters( 'hc_event_capability_type', 'post' ),
		'has_archive' 			=> true, 
		'hierarchical' 			=> false,
		'supports' 				=> apply_filters( 'hc_event_supports', array( 'title', 'editor', 'thumbnail') ),
		'taxonomies' => array('Calendar')
	); 
	register_post_type('hc_event', $event_args);

}
add_action('init', 'hc_setup_post_types', 100);


function hc_event_admin_menu_icon() {
?>
<style type="text/css">
#adminmenu #menu-posts-hc_event div.wp-menu-image{
	background: transparent url(<?php echo HC_PLUGIN_URL; ?>assets/images/calendar.png) no-repeat 6px -17px;
}
#adminmenu #menu-posts-hc_event:hover div.wp-menu-image,
#adminmenu #menu-posts-hc_event.wp-has-current-submenu div.wp-menu-image {
	background-position: 6px 6px;
</style>
<?php
}
add_action( 'admin_head', 'hc_event_admin_menu_icon' );