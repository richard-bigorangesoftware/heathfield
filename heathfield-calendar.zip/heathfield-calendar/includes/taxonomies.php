<?php

/**
 * Setup Event Taxonomies
 *
 * Registers the custom taxonomies.
 *
 * @access      private
 * @since       1.0 
 * @return      void
*/

function hc_setup_event_taxonomies() {

	$category_labels = array(
		'name' 			=> _x( 'Categories', 'taxonomy general name', 'bos_hc' ),
		'singular_name' => _x( 'Category', 'taxonomy singular name', 'bos_hc' ),
		'search_items' 	=>  __( 'Search Categories', 'bos_hc'  ),
		'all_items' 	=> __( 'All Categories', 'bos_hc'  ),
		'parent_item' 	=> __( 'Parent Category', 'bos_hc'  ),
		'parent_item_colon' => __( 'Parent Category:', 'bos_hc'  ),
		'edit_item' => __( 'Edit Category', 'bos_hc'  ), 
		'update_item' => __( 'Update Category', 'bos_hc'  ),
		'add_new_item' => __( 'Add New Category', 'bos_hc'  ),
		'new_item_name' => __( 'New Category Name', 'bos_hc'  ),
		'menu_name' => __( 'Categories', 'bos_hc'  ),
	); 	

	register_taxonomy('hc_event_category', array('hc_event'), array(
		'hierarchical' => true,
		'labels' => apply_filters('hc_event_category_labels', $category_labels),
		'show_ui' => true,
		'query_var' => 'hc_event_category',
		'rewrite' => apply_filters('hc_event_category_rewrite', array('slug' => 'events/category', 'with_front' => false))
	));
	
}
add_action('init', 'hc_setup_event_taxonomies', 10);