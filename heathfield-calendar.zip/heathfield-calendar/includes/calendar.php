<?php

/**
* Sets up the HTML, including forms, around the calendar
*
*/

/** To be completed **/
function getTermDetails( $dtCurrentDate = null ){
    $arrTermTimes =  array(
        array(
            'blnFirst' => true,
            'dtStart' => 1377993600,
            'dtEnd' => 1388448000,
            'strName' => 'Winter 2013'
        ),
        array(
            'dtStart' => 1388448001,
            'dtEnd' => 1396310400,
            'strName' => 'Spring 2014'
        ),
        array(
            'dtStart' => 1396310401,
            'dtEnd' => 1406851200,
            'strName' => 'Summer 2014',
            'blnLast' => true
        ),
    );
    foreach ( $arrTermTimes as $arrTerm ){
        if ( $dtCurrentDate >= $arrTerm['dtStart'] && $dtCurrentDate <= $arrTerm['dtEnd'] ){
            return $arrTerm;
        }
    }
    /**If nothing found return the last term on file **/
    return $arrTerm;
}

function hc_get_events_calendar( $year_override = null, $dtStart = null, $insCalendar = 'School' ) {
    hc_enqueue_styles();

    if( !$dtStart ){
        $dtStart = mktime();
    }
    $arrTermDetails = getTermDetails( $dtStart );

    //2419200 = 4 week - allows leeway for next/prev term
    if ( !$arrTermDetails['blnFirst'] ){
        $strPrevURL = add_query_arg( array( 'dtStart'=>$arrTermDetails['dtStart'] - 2419200 ), get_permalink());
        $strPrevURL = "<a href='$strPrevURL#hc-top' class='hc-prev-term'>previous term</a>";
    } else {
        $strPrevURL = "<span class='hc-space-term'></span>";
    }
    if ( !$arrTermDetails['blnLast'] ){
        $strNextURL = add_query_arg( array( 'dtStart'=>$arrTermDetails['dtEnd'] + 2419200 ), get_permalink());
        $strNextURL = "<a href='$strNextURL#hc-top' class='hc-next-term'>next term</a>";
    } else {
        $strNextURL = "<span class='hc-space-term-last'></span>";
    }
    $strHTML = "    <div class='floatClear'></div>
                    $strPrevURL
                    $strNextURL
                    <h1 class='hc-term-title'>{$arrTermDetails['strName']}</h1>
                    <div class='floatClear'></div>
            ";

    $strHTML.= "<div class='hc-month-wrapper'>";
    $dtMonthStart = $arrTermDetails['dtStart'];
    while( $dtMonthStart < $arrTermDetails['dtEnd'] ){
        $strNextURL = add_query_arg( array( 'dtStart'=>$dtMonthStart ), get_permalink());
        $strHTML.= "<a href='{$strNextURL}#hc-top' class='hc-month-link'>". date( "F", $dtMonthStart ) ."</a>";
        $dtMonthStart = mktime(1, 1, 1, date("n", $dtMonthStart )+1, date("j", $dtMonthStart ), date("y", $dtMonthStart ));
    }
    $strHTML.= "
            </div>
            <div class='floatClear'></div>
        ";

    //604800 = 4 week - allows leeway for next/prev term
    $dtEndOfWeek = strtotime( 'next sunday', $dtStart );
    if(date( 'w', $dtStart ) > 0){
        $dtStartOfWeek = strtotime( 'last sunday', $dtStart );
    } else {
        $dtStartOfWeek = strtotime( 'today', $dtStart );
    }
    $dtStartOfWeek = strtotime( '+1 day', $dtStartOfWeek );
    $strNextURL = add_query_arg( array( 'dtStart'=>$dtStart + 604800 ), get_permalink());
    $strPrevURL = add_query_arg( array( 'dtStart'=>$dtStart - 604800 ), get_permalink());
    $strHTML.= "
                    <a href='$strPrevURL#hc-top' class='hc-prev-week'>previous week</a>
                    <a href='$strNextURL#hc-top' class='hc-next-week'>next week</a>
                    <h2 class='hc-week-title'>week ending ". date( 'jS F', $dtEndOfWeek ). "</h2>
                    <div class='floatClear'></div>
                    <div class='hc-calendar-days-wrapper'>
            ";
    
    $dtCurrent = $dtStartOfWeek;
    
    $i=0;
    while( $dtCurrent < $dtEndOfWeek ){
        $i++;
        $dtEndOfDay = strtotime( '+1 day', $dtCurrent );
        if ( $i==6 ){
            $strDateTitle = "Weekend " . date( "jS", $dtCurrent ) .'/'. date( "jS", $dtEndOfDay );
            $dtEndOfDay = strtotime( '+1 day', $dtEndOfDay );
        } else {
            $strDateTitle = date( "l jS", $dtCurrent );
        }
        
        $arrFilter = array(
                        array(
                                'key' => 'hc_event_date_time',
                                'value' => $dtCurrent,
                                'compare' => '>='
                            ),
                        array(
                                'key' => 'hc_event_date_time',
                                'value' => $dtEndOfDay,
                                'compare' => '<='
                        )
                    );
        
        if(!is_user_logged_in()){
            $arrFilter[] = array(
                    'key' => 'hc_private',
                    'value' => 0,
                    'compare' => '='
                );
        }
        $events = new WP_Query(array(
                'post_type' => 'hc_event',
                'posts_per_page' => -1,
                'orderby' => 'meta_value',
                'meta_key' => 'hc_event_date_time',
                'calendar' => $insCalendar,
                'meta_query' => $arrFilter
            ));
        $dtCurrent = $dtEndOfDay;
        $strHTML.= "
                <div class='calendar-day day-$i'>
                    <span class='hc-calendar-day-title'>$strDateTitle</span>
                    ". transformCalendarPostsToHTML( $events, false, false )."
                </div>
            ";
    }
    $strHTML.="<div class='floatClear'></div></div>";
    echo "
            <a name='hc-top'></a>
            <div id='hc-calendar-wrapper'>
                $strHTML
                <div class='floatClear'></div>
            </div>
        ";
}