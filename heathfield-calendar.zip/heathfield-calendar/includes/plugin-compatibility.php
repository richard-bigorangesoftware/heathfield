<?php

function hc_3rd_party_post_type_supports() {
	/* support for Genesis extras */
	add_post_type_support( 'hc_event', 'genesis-seo' );
	add_post_type_support( 'hc_event', 'genesis-layouts' );
	add_post_type_support( 'hc_event', 'genesis-simple-sidebars' );
}
add_action('init', 'hc_3rd_party_post_type_supports');