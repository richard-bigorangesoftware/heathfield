<?php

function hc_events_list_shortcode( $atts, $content = null ) {
	$calendar = ( isset($atts['calendar']) ) ? $atts['calendar'] : null ;
	return '<div id="hc_calendar_wrap">' . hc_get_events_list( null,null,(int)$_GET['intMonth'],(int)$_GET['intYear'], $calendar) . '</div>';
}

function hc_events_calendar_shortcode( $atts, $content = null ) {
	$calendar = ( isset($atts['calendar']) ) ? $atts['calendar'] : null ;
	return '<div id="hc_calendar_wrap">' . hc_get_events_calendar( null, (int)$_GET['dtStart'], $calendar) . '</div>';
}
add_shortcode( 'hc_events_list', 'hc_events_list_shortcode' );
add_shortcode( 'hc_events_calendar', 'hc_events_calendar_shortcode' );