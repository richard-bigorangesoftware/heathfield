=== Heathfield Calendar Lite ===
Author: Big Orange Software
Author URI: http://bigorangesoftware.com
Plugin URI: http://bigorangesoftware.com
Requires at least: 3.2
Tested up to: 3.7
Stable tag: 1.0.0

Heathfield School Calendar.

== Description ==

Heathfield School Calendar.

= Features =


== Installation ==

== Screenshots ==

== Frequently Asked Questions ==

== Changelog ==