<?php
/*
Plugin Name: Heathfield Calendar for WordPress
Author: Big Orange Software
Author URI: http://www.bigorangesoftware.com
Version: 1.0.0
Text Domain: bos_hc
Domain Path: /languages/
*/


/*
|--------------------------------------------------------------------------
| CONSTANTS
|--------------------------------------------------------------------------
*/

// plugin folder url
if(!defined('HC_PLUGIN_URL')) {
	define('HC_PLUGIN_URL', plugin_dir_url( __FILE__ ));
}
// plugin folder path
if(!defined('HC_PLUGIN_DIR')) {
	define('HC_PLUGIN_DIR', plugin_dir_path( __FILE__ ));
}
// plugin root file
if(!defined('HC_PLUGIN_FILE')) {
	define('HC_PLUGIN_FILE', __FILE__);
}


/*
|--------------------------------------------------------------------------
| INTERNATIONALIZATION
|--------------------------------------------------------------------------
*/

function hc_textdomain() {
	load_plugin_textdomain( 'bos_hc', false, dirname( plugin_basename( HC_PLUGIN_FILE ) ) . '/languages/' );
}
add_action('init', 'hc_textdomain', 1);


/*
|--------------------------------------------------------------------------
| File Includes
|--------------------------------------------------------------------------
*/

include_once( HC_PLUGIN_DIR . '/includes/install.php');
include_once( HC_PLUGIN_DIR . '/includes/post-types.php');
include_once( HC_PLUGIN_DIR . '/includes/custom-taxonomy.php');
include_once( HC_PLUGIN_DIR . '/includes/list-table-columns.php');
include_once( HC_PLUGIN_DIR . '/includes/scripts.php');
include_once( HC_PLUGIN_DIR . '/includes/ajax.php');
include_once( HC_PLUGIN_DIR . '/includes/meta-boxes.php');
include_once( HC_PLUGIN_DIR . '/includes/calendar.php');
include_once( HC_PLUGIN_DIR . '/includes/events-list.php');
include_once( HC_PLUGIN_DIR . '/includes/functions.php');
include_once( HC_PLUGIN_DIR . '/includes/shortcodes.php');
include_once( HC_PLUGIN_DIR . '/includes/event-display.php');
include_once( HC_PLUGIN_DIR . '/includes/query-filters.php');
include_once( HC_PLUGIN_DIR . '/includes/plugin-compatibility.php');
include_once( HC_PLUGIN_DIR . '/includes/event-import.php' );
