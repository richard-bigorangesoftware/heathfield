jQuery(document).ready(function($) {
	if($('.hc_meta_box_row .hc_datepicker').length > 0 ) {
		var dateFormat = 'mm/dd/yy';
		$('.hc_datepicker').datepicker({dateFormat: dateFormat});
	}	
	$('.hc_event_recurring').change(function() {
		var selected = $(':selected', this).val();
		if( selected != 'none' ) {
			$('.hc_recurring_help').show();
		} else {
			$('.hc_recurring_help').hide();
		}
	});
});