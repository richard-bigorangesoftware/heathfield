jQuery(document).ready(function($) {
	$('body').on('submit', '.hc_events_form', function() {

		document.body.style.cursor = 'wait';
		if( $(this).attr('id') == 'hc_event_select' ) {
			var calendar = $(this).parent().parent().parent().attr('id');
		} else {
			var calendar = $(this).parent().parent().parent().parent().attr('id');
		}
		var data = $(this).serialize();
	    $.post(hc_vars.ajaxurl, data, function (response) {
	   		$('#' + calendar).html(response);
	 	}).done(function() {
	 		document.body.style.cursor = 'default';
	 	});
		return false;
	});
});